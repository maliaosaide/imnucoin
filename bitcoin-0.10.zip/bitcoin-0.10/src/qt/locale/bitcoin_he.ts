<TS language="he" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>יצירת כתובת חדשה</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;חדשה</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>העתקת הכתובת המסומנת ללוח הגזירים</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>ה&amp;עתקה</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>סגירה</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>העתקת כתובת</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>מחיקת הכתובת שנבחרה מהרשימה</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>יצוא הנתונים מהלשונית הנוכחית לקובץ</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>י&amp;צוא</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>מ&amp;חיקה</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>נא לבחור את הכתובת המבוקשת לשליחת המטבעות</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>נא לבחור את הכתובת המבוקשת לקבלת המטבעות</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>בחירה</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>כתובות לשליחה</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>כתובות לקבלה</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>אלה כתובת הביטקוין שלך לצורך שליחת תשלומים. תמיד יש לבדוק את הכמות ואת כתובות מקבלי התשלומים לפני שליחת מטבעות.</translation>
    </message>
    <message>
        <source>These are your Bitcoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>אלה כתובות הביטקוין שלך לצורך קבלת תשלומים. מומלץ להשתמש בכתובת קבלה חדשה לכל העברה.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>העתקת &amp;תווית</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>ע&amp;ריכה</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>יצוא רשימת כתובות</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>קובץ מופרד בפסיקים (‎*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>היצוא נכשל</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>אירעה שגיאה בעת הניסיון לשמור את רשימת הכתובת אל %1. נא לנסות שוב.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>תווית</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>כתובת</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ללא תווית)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>דו־שיח מילת צופן</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>נא להזין מילת צופן</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>מילת צופן חדשה</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>נא לחזור על מילת הצופן החדשה</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>הצפנת הארנק</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>פעולה זו דורשת את מילת הצופן של הארנק שלך כדי לפתוח את הארנק.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>פתיחת ארנק</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>פעולה זו דורשת את מילת הצופן של הארנק שלך כדי לפענח את הארנק.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>פענוח ארנק</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>שינוי מילת צופן</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>נא להכניס את מילות הצופן הישנה והחדשה לארנק.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>אישור הצפנת הארנק</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BITCOINS&lt;/b&gt;!</source>
        <translation>אזהרה: הצפנת הארנק ואיבוד מילת הצופן עשויה להוביל &lt;b&gt;לאיבוד כל הביטקוינים שלך&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>האם אכן להצפין את הארנק?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>לתשומת לבך: כל גיבוי קודם שביצעת לארנק שלך יש להחליף בקובץ הארנק המוצפן שזה עתה נוצר. מטעמי אבטחה, גיבויים קודמים של קובץ הארנק הבלתי-מוצפן יהפכו לחסרי תועלת עם התחלת השימוש בארנק החדש המוצפן.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>זהירות: מקש Caps Lock פעיל!</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>הארנק הוצפן</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>נא להזין את מילת הצופן החדשה לארנק.&lt;br/&gt;כדאי להשתמש במילת צופן המורכבת מ&lt;b&gt;עשרה תווים אקראיים ומעלה&lt;/b&gt;, או &lt;b&gt;שמונה מילים ומעלה&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Bitcoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your bitcoins from being stolen by malware infecting your computer.</source>
        <translation>ביטקוין ייסגר כעת כדי להשלים את תהליך ההצפנה. עליך לזכור שהצפנת הארנק שלך אינה מגנה באופן מלא על הביטקוינים שלך מתכניות זדוניות המושתלות על המחשב.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>הצפנת הארנק נכשלה</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>הצפנת הארנק נכשלה עקב שגיאה פנימית. הארנק שלך לא הוצפן.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>מילות הצופן שסופקו אינן תואמות.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>פתיחת הארנק נכשלה</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>מילת הצופן שהוכנסה לפענוח הארנק שגויה.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>פענוח הארנק נכשל</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>מילת הצופן של הארנק שונתה בהצלחה.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>&amp;חתימה על הודעה…</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>בסנכרון עם הרשת…</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;סקירה</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>מפרק</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>הצגת סקירה כללית של הארנק</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>ה&amp;עברות</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>עיון בהיסטוריית ההעברות</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>י&amp;ציאה</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>יציאה מהתכנית</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>על אודות Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>הצגת מידע על Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;אפשרויות…</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>ה&amp;צפנת הארנק…</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;גיבוי הארנק…</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>ה&amp;חלפת מילת הצופן…</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>כתובת ה&amp;שליחה…</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>כתובות ה&amp;קבלה…</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>פתיחת &amp;כתובת משאב…</translation>
    </message>
    <message>
        <source>Bitcoin Core client</source>
        <translation>לקוח ליבה של ביטקוין</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>מקטעים מיובאים מהכונן…</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>המקטעים נוספים למפתח בכונן…</translation>
    </message>
    <message>
        <source>Send coins to a Bitcoin address</source>
        <translation>שליחת מטבעות לכתובת ביטקוין</translation>
    </message>
    <message>
        <source>Modify configuration options for Bitcoin</source>
        <translation>שינוי התצורה של ביטקוין</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>גיבוי הארנק למיקום אחר</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>החלפת מילת הצופן להצפנת הארנק</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>חלון &amp;ניפוי</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>פתיחת לוח הבקרה לאבחון ולניפוי</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;אימות הודעה…</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>ביטקוין</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>ארנק</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;שליחה</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;קבלה</translation>
    </message>
    <message>
        <source>Show information about Bitcoin Core</source>
        <translation>הצגת מידע על ליבת ביטקוין</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>ה&amp;צגה / הסתרה</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>הצגה או הסתרה של החלון הראשי</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>הצפנת המפתחות הפרטיים ששייכים לארנק שלך</translation>
    </message>
    <message>
        <source>Sign messages with your Bitcoin addresses to prove you own them</source>
        <translation>חתום על הודעות עם כתובות הביטקוין שלך כדי להוכיח שהן בבעלותך</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Bitcoin addresses</source>
        <translation>אמת הודעות כדי להבטיח שהן נחתמו עם כתובת ביטקוין מסוימות</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;קובץ</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>ה&amp;גדרות</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>ע&amp;זרה</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>סרגל כלים לשוניות</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>ליבת ביטקוין</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and bitcoin: URIs)</source>
        <translation>בקשת תשלומים (יצירה של קודים מסוג QR וסכימות כתובות משאב של :bitcoin)</translation>
    </message>
    <message>
        <source>&amp;About Bitcoin Core</source>
        <translation>על &amp;אודות ליבת ביטקוין</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>הצג את רשימת הכתובות לשליחה שהיו בשימוש לרבות התוויות</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>הצגת רשימת הכתובות והתוויות הנמצאות בשימוש</translation>
    </message>
    <message>
        <source>Open a bitcoin: URI or payment request</source>
        <translation>פתיחת ביטקוין: כתובת משאב או בקשת תשלום</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>אפשרויות &amp;שורת הפקודה</translation>
    </message>
    <message>
        <source>Show the Bitcoin Core help message to get a list with possible Bitcoin command-line options</source>
        <translation>הצגת הודעות העזרה של ליבת ביטקוין כדי לקבל רשימה עם אפשרויות שורת הפקודה האפשריות של ביטקוין</translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>אין מקור מקטעים זמין…</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n שעה</numerusform><numerusform>%n שעות</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n יום</numerusform><numerusform>%n ימים</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n שבוע</numerusform><numerusform>%n שבועות</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 ו%2</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>המקטע האחרון שהתקבל נוצר לפני %1.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>ההעברות שבוצעו לאחר העברה זו לא יופיעו.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>אזהרה</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>מידע</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>עדכני</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>מתבצע עדכון…</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>העברת שליחה</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>העברת קבלה</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>תאריך: %1
כמות: %2
סוג: %3
כתובת: %4</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>הארנק &lt;b&gt;מוצפן&lt;/b&gt; ו&lt;b&gt;פתוח&lt;/b&gt; כרגע</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>הארנק &lt;b&gt;מוצפן&lt;/b&gt; ו&lt;b&gt;נעול&lt;/b&gt; כרגע</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>אזעקת רשת</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>כמות:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>בתים:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>כמות:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>עדיפות:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>תשלום:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>אבק:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>לאחר עמלה:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>שינוי:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>ביטול/אישור הבחירה</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>מצב עץ</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>מצב רשימה</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>כמות</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>תאריך</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>אישורים</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>מאושר</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>עדיפות</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>העתקת כתובת</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>העתקת תווית</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>העתקת כמות</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>העתקת מזהה העברה</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>נעילת יתרה</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>פתיחת יתרה</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>העתקת כמות</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>העתקת מחיר</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>העתקת אחרי עמלה</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>העתקת בתים</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>העתקת עדיפות</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>העתקת אבק</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>העתקת עודף</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>הגבוה ביותר</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>גבוה יותר</translation>
    </message>
    <message>
        <source>high</source>
        <translation>גבוה</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>בינוני - גבוה</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>בינוני</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>בינוני - נמוך</translation>
    </message>
    <message>
        <source>low</source>
        <translation>נמוך</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>נמוך יותר</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>הנמוך ביותר</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ללא</translation>
    </message>
    <message>
        <source>Can vary +/- %1 satoshi(s) per input.</source>
        <translation>יכולה להשתנות ב+/- %1 סטושי לקלט.</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>כן</translation>
    </message>
    <message>
        <source>no</source>
        <translation>לא</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>תווית זו מאדימה אם גודל ההעברה עולה על 1000 בתים.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>זאת אומרת שנחוצה עמלה של לא פחות מ־%1 לכל קילו בית.</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>הערך יכול להיות +/- בית אחד לכל קלט.</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>העברות עם עדיפות גבוהה, יותר סיכוי שיכנסו לתוך המקטע.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than "medium".</source>
        <translation>תווית זו מאדימה אם העדיפות היא פחות מ„בינוני“</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(אין תווית)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>עודף מ־%1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(עודף)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>עריכת כתובת</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>ת&amp;ווית</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>התווית המשויכת לרשומה הזו ברשימת הכתובות</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>הכתובת המשויכת עם רשומה זו ברשימת הכתובות. ניתן לשנות זאת רק עבור כתובות לשליחה.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;כתובת</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>כתובת חדשה לקבלה</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>כתובת חדשה לשליחה</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>עריכת כתובת לקבלה</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>עריכת כתובת לשליחה</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>הכתובת שהוכנסה „%1“ כבר נמצאת בפנקס הכתובות.</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Bitcoin address.</source>
        <translation>הכתובת שהוכנסה „%1“ אינה כתובת ביטקוין תקנית.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>פתיחת הארנק נכשלה.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>יצירת מפתח חדש נכשלה.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>תיקיית נתונים חדשה תיווצר.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>שם</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>התיקייה כבר קיימת. ניתן להוסיף %1 אם יש ליצור תיקייה חדשה כאן.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>הנתיב כבר קיים ואינו מצביע על תיקייה.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>לא ניתן ליצור כאן תיקיית נתונים.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>ליבת ביטקוין</translation>
    </message>
    <message>
        <source>version</source>
        <translation>גרסה</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-סיביות)</translation>
    </message>
    <message>
        <source>About Bitcoin Core</source>
        <translation>על אודות ליבת ביטקוין</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>אפשרויות שורת פקודה</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>שימוש:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>אפשרויות שורת פקודה</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>אפשרויות מנשק</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>הגדרת שפה, למשל „he_il“ (בררת מחדל: שפת המערכת)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>התחלה במצב ממוזער</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>הגדרות אישורי בסיס של SSL לבקשות תשלום (בררת המחדל: -מערכת-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>הצגת מסך פתיחה בעת הפעלה (בררת מחדל: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>בחירת תיקיית נתונים עם ההפעלה (בררת מחדל: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>ברוך בואך</translation>
    </message>
    <message>
        <source>Welcome to Bitcoin Core.</source>
        <translation>ברוך בואך לליבת ביטקוין</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Bitcoin Core will store its data.</source>
        <translation>מכיוון שזאת הפעם הראשונה שהתכנית פועלת ניתן לבחור איפה ליבת ביטקוין תאחסן את הנתונים שלה.</translation>
    </message>
    <message>
        <source>Bitcoin Core will download and store a copy of the Bitcoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>לקוח ביטקוין יוריד וישמור העתק של שרשרת המקטעים של ביטקוין. לפחות %1 ג״ב מהנתונים יאוחסנו בתיקייה זו, והיא תגדל עם הזמן. הארנק גם יאוחסן בתיקייה הזו.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>שימוש בבררת המחדל של תיקיית הנתונים.</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>שימוש בתיקיית נתונים מותאמת אישית:</translation>
    </message>
    <message>
        <source>Bitcoin Core</source>
        <translation>ליבת ביטקוין</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>שגיאה: לא ניתן ליצור את תיקיית הנתונים שצוינה „%1“.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>פתיחת כתובת משאב</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>פתיחת בקשת תשלום מכתובת משאב או מקובץ</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>כתובת משאב:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>בחירת קובץ בקשת תשלום</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>בחירת קובץ בקשת תשלום לפתיחה</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>אפשרויות</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;ראשי</translation>
    </message>
    <message>
        <source>Automatically start Bitcoin after logging in to the system.</source>
        <translation>הפעלת ביטקוין אוטומטית לאחר כניסה למערכת.</translation>
    </message>
    <message>
        <source>&amp;Start Bitcoin on system login</source>
        <translation>ה&amp;פעלת ביטקוין בעת הכניסה למערכת</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>גודל מ&amp;טמון מסד הנתונים</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>מ״ב</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>מספר תהליכי ה&amp;אימות של הסקריפט</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>קבלת חיבורים מבחוץ</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>לאפשר חיבורים נכנסים</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>כתובת ה־IP של המתווך (לדוגמה IPv4: 127.0.0.1‏ / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>כתובות צד־שלישי (כגון: סייר מקטעים) שמופיעים בלשונית ההעברות בתור פריטים בתפריט ההקשר. %s בכתובת מוחלף בגיבוב ההעברה. מספר כתובות יופרדו בפס אנכי |.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>כתובות העברה צד־שלישי</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>אפשרויות פעילות בשורת הפקודה שדורסות את האפשרויות שלהלן:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>איפוס כל אפשרויות התכנית לבררת המחדל.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;איפוס אפשרויות</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;רשת</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = אוטומטי, &lt;0 = להשאיר כזאת כמות של ליבות חופשיות)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>&amp;ארנק</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>מומחה</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>הפעלת תכונות &amp;בקרת מטבעות</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>אם אפשרות ההשקעה של עודף בלתי מאושר תנוטרל, לא ניתן יהיה להשתמש בעודף מההעברה עד שלהעברה יהיה לפחות אישור אחד. פעולה זו גם משפיעה על חישוב המאזן שלך.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>עודף &amp;בלתי מאושר מההשקעה</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>פתיחת הפתחה של ביטקוין בנתב באופן אוטומטי. עובד רק אם UPnP מופעל ונתמך בנתב.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>מיפוי פתחה באמצעות UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>כתובת ה־IP של המ&amp;תווך:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;פתחה:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>הפתחה של המתווך (למשל 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;חלון</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>הצג סמל מגש בלבד לאחר מזעור החלון.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>מ&amp;זעור למגש במקום לשורת המשימות</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>מזעור התכנית במקום לצאת ממנה כשהחלון נסגר. כשאפשרות זו פעילה, התכנית תיסגר רק לאחר בחירת יציאה מהתפריט.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>מ&amp;זעור עם סגירה</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>ת&amp;צוגה</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;שפת מנשק המשתמש:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Bitcoin.</source>
        <translation>להלן ניתן לקבוע את שפת מנשק המשתמש. הגדרה זו תיכנס לתוקף לאחר הפעלה מחדש של ביטקוין.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>י&amp;חידת מידה להצגת כמויות:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>ניתן לבחור את בררת המחדל ליחידת החלוקה שתוצג במנשק ובעת שליחת מטבעות.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>האם להציג תכונות שליטת מטבע או לא.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;אישור</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;ביטול</translation>
    </message>
    <message>
        <source>default</source>
        <translation>בררת מחדל</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ללא</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>אישור איפוס האפשרויות</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>נדרשת הפעלה מחדש של הלקוח כדי להפעיל את השינויים.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>הלקוח יכבה, האם להמשיך?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>שינוי זה ידרוש הפעלה מחדש של תכנית הלקוח.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>כתובת המתווך שסופקה אינה תקינה.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>טופס</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>המידע המוצג עשוי להיות מיושן. הארנק שלך מסתנכרן באופן אוטומטי עם רשת הביטקוין לאחר יצירת החיבור, אך התהליך טרם הסתיים.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>צפייה בלבד:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>זמין:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>היתרה הזמינה הנוכחית</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>בהמתנה:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>הסכום הכולל של העברות שטרם אושרו ועדיין אינן נספרות בחישוב היתרה הזמינה</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>לא בשל:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>מאזן שנכרה וטרם הבשיל</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>מאזנים</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>סך הכול:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>סך כל היתרה הנוכחית שלך</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>המאזן הנוכחי שלך בכתובות לקריאה בלבד</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>העברות אחרונות</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>העברות בלתי מאושרות לכתובות לצפייה בלבד</translation>
    </message>
    <message>
        <source>Mined balance in watch-only addresses that has not yet matured</source>
        <translation>מאזן לאחר כרייה בכתובות לצפייה בלבד שעדיין לא הבשילו</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>המאזן הכולל הנוכחי בכתובות לצפייה בלבד</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>לא בסנכרון</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>תפעול כתובות משאב</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>כתובת תשלום שגויה %1</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>בקשת התשלום נדחתה</translation>
    </message>
    <message>
        <source>Payment request network doesn't match client network.</source>
        <translation>רשת בקשת התשלום אינה תואמת לרשת הלקוח.</translation>
    </message>
    <message>
        <source>Payment request has expired.</source>
        <translation>בקשת התשלום פגה.</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>בקשת התשלום לא החלה.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>הסכום על סך %1 הנדרש לתשלום קטן מדי (נחשב לאבק)</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>שגיאה בבקשת תשלום</translation>
    </message>
    <message>
        <source>Cannot start bitcoin: click-to-pay handler</source>
        <translation>לא ניתן להתחיל את ביטקוין: טיפול בלחיצה–לתשלום </translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>כתובת אחזור בקשת התשלום שגויה: %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid Bitcoin address or malformed URI parameters.</source>
        <translation>לא ניתן לנתח את כתובת המשאב! מצב זה יכול לקרות עקב כתובת ביטקוין שגויה או פרמטרים שגויים בכתובת המשאב.</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>טיפול בקובצי בקשות תשלום</translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>לא ניתן לקרוא את קובץ בקשת התשלום! מצב כזה יכול לקרות בעקבות קובץ בקשת תשלום פגום.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>בקשות תשלום בלתי מאומתות לסקריפטים לתשלום מותאמים אישית אינן נתמכות.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>החזר מ־%1</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>שגיאה בתקשורת עם %1: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>לא ניתן לפענח את בקשת התשלום!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>מענה שגוי משרת %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>התשלום התקבל</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>שגיאת בקשת שרת</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>סוכן משתמש</translation>
    </message>
    <message>
        <source>Address/Hostname</source>
        <translation>כתובת/שם מארח</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>זמן המענה</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>כמות</translation>
    </message>
    <message>
        <source>Enter a Bitcoin address (e.g. %1)</source>
        <translation>נא להזין כתובת ביטקוין (למשל: %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 ימים</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 שעות</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 דקות</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 שניות</translation>
    </message>
    <message>
        <source>NETWORK</source>
        <translation>רשת</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>לא ידוע</translation>
    </message>
    <message>
        <source>None</source>
        <translation>ללא</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>לא זמין</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 מילישניות</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;שמירת תמונה…</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>ה&amp;עתקת תמונה</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>שמירת קוד QR</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>תמונת PNG ‏(‎*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>שם לקוח</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>לא זמין</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>גרסת מנשק</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>מי&amp;דע</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>חלון ניפוי</translation>
    </message>
    <message>
        <source>General</source>
        <translation>כללי</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>שימוש ב־OpenSSL גרסה</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>שימוש ב־BerkeleyDB גרסה</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>זמן עלייה</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>רשת</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>שם</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>מספר חיבורים</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>שרשרת מקטעים</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>מספר המקטעים הנוכחי</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>התקבלו</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>נשלחו</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;עמיתים</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>נא לבחור בעמית כדי להציג מידע מפורט.</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>כיוון</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>גרסה</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>סוכן משתמש</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>שירותים</translation>
    </message>
    <message>
        <source>Starting Height</source>
        <translation>גובה התחלתי</translation>
    </message>
    <message>
        <source>Sync Height</source>
        <translation>גובה הסנכרון</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>דירוג חסימה</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>זמן החיבור</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>שליחה אחרונה</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>קבלה אחרונה</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation>בתים שנשלחו</translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation>בתים שהתקבלו</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>זמן המענה</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>זמן המקטע האחרון</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;פתיחה</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>מ&amp;סוף בקרה</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;תעבורת רשת</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;ניקוי</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>סכומים</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>נכנס:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>יוצא:</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>תאריך בנייה</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>קובץ יומן ניפוי</translation>
    </message>
    <message>
        <source>Open the Bitcoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>פתיחת קובץ יומן הניפוי מתיקיית הנתונים הנוכחית. פעולה זו עשויה להימשך מספר שניות עבור קובצי יומן גדולים.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>ניקוי מסוף הבקרה</translation>
    </message>
    <message>
        <source>Welcome to the Bitcoin RPC console.</source>
        <translation>ברוכים הבאים למסוף ה־RPC של ביטקוין.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>יש להשתמש בחצים למעלה ולמטה כדי לנווט בהיסטוריה, וב־&lt;b&gt;Ctrl-L&lt;/b&gt; כדי לנקות את המסך.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>ניתן להקליד &lt;b&gt;help&lt;/b&gt; לקבלת סקירה של הפקודות הזמינות.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 ב׳</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 ק״ב</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 מ״ב</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 ג״ב</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>דרך %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>לעולם לא</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>תעבורה נכנסת</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>תעבורה יוצאת</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>לא ידוע</translation>
    </message>
    <message>
        <source>Fetching...</source>
        <translation>מתקבל…</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;סכום:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>ת&amp;ווית:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>הו&amp;דעה:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>ניתן להשתמש שוב באחת מכתובות הקבלה שכבר נעשה בהן שימוש. לשימוש חוזר בכתובות ישנן השלכות אבטחה ופרטיות. מומלץ שלא להשתמש באפשרות זו למעט יצירה מחדש של בקשת תשלום שנוצרה בעבר.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>ש&amp;ימוש &amp;חוזר בכתובת קבלה קיימת (לא מומלץ)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Bitcoin network.</source>
        <translation>הודעת רשות לצירוף לבקשת התשלום שתוצג בעת פתיחת הבקשה. לתשומת לבך: ההודעה לא תישלח עם התשלום ברשת ביטקוין.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>תווית רשות לשיוך עם כתובת הקבלה החדשה.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>יש להשתמש בטופס זה כדי לבקש תשלומים. כל השדות הם בגדר &lt;b&gt;רשות&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>סכום כרשות לבקשה. ניתן להשאיר זאת ריק כדי לא לבקש סכום מסוים.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>ניקוי כל השדות של הטופס.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>ניקוי</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>היסטוריית בקשות תשלום</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;בקשת תשלום</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>הצגת בקשות נבחרות (דומה ללחיצה כפולה על רשומה)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>הצגה</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>הסרת הרשומות הנבחרות מהרשימה</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>הסרה</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>העתקת תווית</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>העתקת הודעה</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>העתקת כמות</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>קוד QR</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>העתקת &amp;כתובת משאב</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>העתקת &amp;כתובת</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;שמירת תמונה…</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>בקשת תשלום לטובת %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>מידע על תשלום</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>כתובת משאב</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>כתובת</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>כמות</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>תווית</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>הודעה</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>כתובת המשאב המתקבלת ארוכה מדי, כדאי לנסות לצמצם את הטקסט בתווית / הודעה.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>שגיאה בקידוד כתובת משאב לקוד QR</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>תאריך</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>תווית</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>הודעה</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>כמות</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(אין תווית)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(אין הודעה)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(אין סכום)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>שליחת מטבעות</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>תכונות בקרת מטבעות</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>קלטים…</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>בבחירה אוטומטית</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>אין מספיק כספים!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>כמות:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>בתים:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>סכום:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>עדיפות:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>עמלה:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>לאחר עמלה:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>עודף:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>אם אפשרות זו מופעלת אך כתובת העודף ריקה או שגויה, העודף יישלח לכתובת חדשה שתיווצר.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>כתובת לעודף מותאמת אישית</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>שליחה למספר מוטבים בו־זמנית</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>הוספת &amp;מוטב</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>ניקוי של כל השדות בטופס.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>אבק:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>ניקוי ה&amp;כול</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>מאזן:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>אישור פעולת השליחה</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;שליחה</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>אישור שליחת מטבעות</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 אל %2</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>העתקת כמות</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>העתקת סכום</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>העתקת עמלה</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>העתקת אחרי עמלה</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>העתקת בתים</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>העתקת עדיפות</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>העתקת עודף</translation>
    </message>
    <message>
        <source>or</source>
        <translation>או</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>כתובת המוטב אינה תקינה, נא לבדוק שוב.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>הכמות לתשלום חייבת להיות גדולה מ־0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>הכמות עולה על המאזן שלך.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>הכמות הכוללת, ובכללה עמלת העברה בסך %1, עולה על המאזן שלך.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>כתובת כפולה נמצאה, ניתן לשלוח לכל כתובת רק פעם אחת בכל פעולת שליחה.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>יצירת ההעברה נכשלה!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>ההעברה נדחתה! מצב כזה עשוי לקרות אם חלק מהמטבעות בארנק שלך כבר הושקעו, כמו למשל עקב שימוש בעותק של wallet.dat והמטבעות הושקעו בעותק אבל לא סומנו כאילו הושקעו דרך כאן.</translation>
    </message>
    <message>
        <source>Warning: Invalid Bitcoin address</source>
        <translation>אזהרה: כתובת ביטקוין שגויה</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(אין תווית)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>אזהרה: כתובת עודף בלתי ידועה</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>העתקת אבק</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>האם אכן לשלוח?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>נוסף כעמלת העברה</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;כמות:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>לשלם ל&amp;טובת:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>נא להכניס תווית לכתובת הזאת כדי להוסיף לפנקס הכתובות</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>ת&amp;ווית:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>בחירת כתובת שהייתה בשימוש</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>זהו תשלום רגיל.</translation>
    </message>
    <message>
        <source>The Bitcoin address to send the payment to</source>
        <translation>כתובת הביטקוין של המוטב</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>הדבקת כתובת מלוח הגזירים</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>הסרת רשומה זו</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>הודעה:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>זוהי בקשה מאומתת לתשלום.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>יש להזין תווית עבור כתובת זו כדי להוסיף אותה לרשימת הכתובות בשימוש</translation>
    </message>
    <message>
        <source>A message that was attached to the bitcoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Bitcoin network.</source>
        <translation>הודעה שצורפה לביטקוין: כתובת שתאוחסן בהעברה לצורך מעקב מצדך. לתשומת לבך: הודעה זו לא תישלח ברשת הביטקוין.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>זוהי בקשת תשלום בלתי־מאומתת.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>תשלום לטובת:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>תזכורת:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Bitcoin Core is shutting down...</source>
        <translation>ליבת ביטקוין נסגרת…</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>אין לכבות את המחשב עד שחלון זה נעלם.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>חתימות - חתימה או אימות של הודעה</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>חתימה על הו&amp;דעה</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>ניתן לחתום על הודעות עם הכתובות שלך כדי להוכיח שהן בבעלותך. מומלץ להיזהר לא לחתום על משהו מפוקפק, שכן התקפות דיוג עשויות לגרום לך בעורמה למסור את זהותך. רצוי לחתום רק על הצהרות מפורטות לחלוטין שהסכמת עמן.</translation>
    </message>
    <message>
        <source>The Bitcoin address to sign the message with</source>
        <translation>כתובת הביטקוין אתה לחתום אתה את ההודעה</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>בחירת כתובת שהייתה בשימוש</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>הדבקת כתובת מלוח הגזירים</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>יש להוסיף כאן את ההודעה עליה לחתום</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>חתימה</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>העתקת החתימה הנוכחית ללוח הגזירים</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Bitcoin address</source>
        <translation>ניתן לחתום על ההודעה כדי להוכיח שכתובת הביטקוין הזו בבעלותך.</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;חתימה על הודעה</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>איפוס כל שדות החתימה על הודעה</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;ניקוי הכול</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;אימות הודעה</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>הכנס למטה את הכתובת החותמת, ההודעה (ודא שאתה מעתיק מעברי שורה, רווחים, טאבים וכו' באופן מדויק) והחתימה כדי לאמת את ההודעה. היזהר לא לפרש את החתימה כיותר ממה שמופיע בהודעה החתומה בעצמה, כדי להימנע מליפול קורבן למתקפת איש-באמצע.</translation>
    </message>
    <message>
        <source>The Bitcoin address the message was signed with</source>
        <translation>כתובת הביטקוין שאתה נחתמה ההודעה</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Bitcoin address</source>
        <translation>ניתן לאמת את ההודעה כדי להבטיח שהיא נחתמה עם כתובת הביטקוין הנתונה</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;אימות הודעה</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>איפוס כל שדות אימות ההודעה</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>יש ללחוץ על „חתימה על ההודעה“ כדי לחולל חתימה</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>הכתובת שהוכנסה אינה תקינה.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>נא לבדוק את הכתובת לנסות שנית.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>הכתובת שהוכנסה אינה מתייחסת למפתח.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>פתיחת הארנק בוטלה.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>המפתח הפרטי עבור הכתובת שהוכנסה אינו זמין.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>החתימה על ההודעה נכשלה.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>ההודעה נחתמה.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>לא ניתן לפענח את החתימה.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>נא לבדוק את החתימה ולנסות שנית.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>החתימה לא תואמת את תקציר ההודעה.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>אימות ההודעה נכשל.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>ההודעה אומתה.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Bitcoin Core</source>
        <translation>ליבת ביטקוין</translation>
    </message>
    <message>
        <source>The Bitcoin Core developers</source>
        <translation>מתכנתי ליבת ביטקוין</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[רשת-בדיקה]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>ק״ב/ש׳</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>פתוחה עד %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>מתנגש</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/מנותק</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/המתנה לאישור</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 אישורים</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>מצב</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>תאריך</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>מקור</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>נוצר</translation>
    </message>
    <message>
        <source>From</source>
        <translation>מאת</translation>
    </message>
    <message>
        <source>To</source>
        <translation>אל</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>כתובת עצמית</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>צפייה בלבד</translation>
    </message>
    <message>
        <source>label</source>
        <translation>תווית</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>זיכוי</translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>לא התקבל</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>חיוב</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>סך כל החיוב</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>סך כל האשראי</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>עמלת העברה</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>כמות נקייה</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>הודעה</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>הערה</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>מזהה העברה</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>סוחר</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>מטבעות חדשים שנוצרו חייבים להבשיל במשך %1 מקטעים לפני שניתן לנצל אותם. כשמקטע זה נוצר הוא משודר ברשת על מנת שייכנס לשרשרת המקטעים. אם הוא לא ייכנס לשרשרת, מצבו ישתנה ל„לא התקבל“ ולא ניתן יהיה לנצלו. מצב כזה יכול לקרות מדי פעם אם במקרה מפרק אחר יצר מקטע בהבדל של שניות בודדות ממך.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>מידע ניפוי</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>העברה</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>קלטים</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>כמות</translation>
    </message>
    <message>
        <source>true</source>
        <translation>אמת</translation>
    </message>
    <message>
        <source>false</source>
        <translation>שקר</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, טרם שודר בהצלחה</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>פתיחה למשך מקטע %n נוסף</numerusform><numerusform>פתיחה למשך %n מקטעים נוספים</numerusform></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>לא ידוע</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>פרטי ההעברה</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>חלונית זו מציגה תיאור מפורט של ההעברה</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>תאריך</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>סוג</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>כתובת</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>לא בשל (%1 אישורים, יהיו זמינים לאחר %2)</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>פתח למשך בלוק %n יותר</numerusform><numerusform>פתיחה למשך %n מקטעים נוספים</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>פתוחה עד %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>מאושר (%1 אישורים)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>המקטע הזה לא נקלט על ידי אף מפרק אחר, וכנראה לא יתקבל!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>נוצר אך לא התקבל</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>מנותק</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>ללא אישור</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>מתקבל אישור (%1 מתוך %2 אישורים מומלצים)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>מתנגש</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>התקבל עם</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>התקבל מאת</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>נשלח אל</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>תשלום לעצמך</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>נכרה</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>צפייה בלבד</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(לא זמין)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>מצב ההעברה. יש להמתין עם הסמן מעל שדה זה כדי לראות את מספר האישורים.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>התאריך והשעה בה ההעברה הזאת התקבלה.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>סוג ההעברה.</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>האם כתובות לצפייה בלבד מעורבות בהעברה זאת או שלא.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>כתובת היעד של ההעברה.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>הכמות שהתווספה או הוסרה מהיתרה.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>הכול</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>היום</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>השבוע</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>החודש</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>החודש שעבר</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>השנה</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>טווח…</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>התקבל עם</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>נשלח אל</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>לעצמך</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>נכרה</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>אחר</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>נא להכניס כתובת או תווית לחיפוש</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>כמות מזערית</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>העתקת כתובת</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>העתקת תווית</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>העתקת כמות</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>העתקת מזהה העברה</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>עריכת תווית</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>הצגת פרטי העברה</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>יצוא היסטוריית העברות</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>צפייה בלבד</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>היצוא נכשל</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>אירעה שגיאה בעת ניסיון לשמור את היסטוריית ההעברות אל %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>היצוא בוצע בהצלחה</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>היסטוריית ההעברות נשמרה ל־%1 בהצלחה.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>קובץ מופרד בפסיקים (‎*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>מאושר</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>תאריך</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>סוג</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>תווית</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>כתובת</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>מזהה</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>טווח:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>אל</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>יחידת המידה להצגת הסכומים. יש ללחוץ כדי לבחור ביחידת מידה אחרת.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>לא נטען ארנק</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>שליחת מטבעות</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>י&amp;צוא</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>יצוא הנתונים מהלשונית הנוכחית לקובץ</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>גיבוי ארנק</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>נתוני ארנק (‎*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>גיבוי נכשל</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>אירעה שגיאה בעת ניסיון לשמירת נתוני הארנק אל %1.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>נתוני הארנק נשמרו בהצלחה אל %1.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>הגיבוי הושלם בהצלחה</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>אפשרויות:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>ציון תיקיית נתונים</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>יש להתחבר למפרק כדי לדלות כתובות עמיתים ואז להתנתק</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>נא לציין את הכתובת הפומבית שלך</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>קבלת פקודות משורת הפקודה ומ־JSON-RPC</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>ריצה כסוכן ברקע וקבלת פקודות</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>שימוש ברשת הבדיקה</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>קבלת חיבורים מבחוץ (בררת מחדל: 1 ללא ‎-proxy או ‎-connect)</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>להתאגד לכתובת נתונה להאזין לה תמיד. יש להשתמש בצורה ‎[host]:port עבור IPv6.</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>מחיקת כל העברות הארנק ולשחזר רק את החלקים המסוימים בשרשרת המקטעים באמצעות ‎-rescan עם ההפעלה</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation>כניסה למצב בדיקת נסיגה, שמשתמש בשרשרת מיוחדת בה ניתן לפתור את המקטעים במהירות.</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>ביצוע פקודה כאשר העברה בארנק משתנה (%s ב־cmd יוחלף ב־TxID)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>זוהי בניית ניסיון טרום-שחרור - השימוש בה על אחריותך - אין להשתמש לצורך כריה או יישומי מסחר</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Bitcoin Core is probably already running.</source>
        <translation>לא ניתן להתאגד אל %s במחשב זה. כנראה שליבת ביטקוין כבר פועלת.</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>אזהרה: ‎-paytxfee נקבע לערך מאד גבוה! זוהי עמלת הפעולה שתשולם בעת העברת שליחה.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>אזהרה: נראה שלא כל הרשת מסכימה! נראה שישנם כורים שנתקלים בבעיות.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>אזהרה: נראה שישנה אי־הסכמה בינינו לבין שאר העמיתים שלנו! יתכן שעדיף לשדרג או שכל שאר העמיתים צריכים לשדרג.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>אזהרה: שגיאה בקריאת wallet.dat! כל המפתחות נקראו באופן תקין, אך נתוני ההעברות או ספר הכתובות עלולים להיות חסרים או שגויים.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>אזהרה: הקובץ wallet.dat הושחת, המידע חולץ! קובץ ה־wallet.dat המקורי נשמר בשם wallet.{timestamp}.bak במיקום %s; אם המאזן או ההעברות שגויים עליך לשחזר גיבוי.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(בררת מחדל: 1)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;קטגוריה&gt; יכולה להיות:</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>נסה לשחזר מפתחות פרטיים מקובץ wallet.dat מושחת.</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>אפשרויות יצירת מקטע:</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>התחבר רק לצמתים המצוינים</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>הגדרות חיבור:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>התגלה מסד נתוני מקטעים לא תקין</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>אפשרויות ניפוי/בדיקה:</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>לגלות את כתובת ה־IP העצמית (בררת מחדל: 1 בעת האזנה וללא ‎-externalip)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>לא לטעון את הארנק ולנטרל קריאות RPC</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>האם לבנות מחדש את מסד נתוני המקטעים?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>שגיאה באתחול מסד נתוני המקטעים</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>שגיאה באתחול סביבת מסד נתוני הארנקים %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>שגיאה בטעינת מסד נתוני המקטעים</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>שגיאה בטעינת מסד נתוני המקטעים</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>שגיאה: מעט מקום פנוי בכונן!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>האזנה נכשלה בכל פורט. השתמש ב- -listen=0 אם ברצונך בכך.</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>אם לא סופקה &lt;קטגוריה&gt; יש לייצא את כל פרטי הניפוי.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>מתבצע יבוא…</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>מקטע הפתיח הוא שגוי או לא נמצא. תיקיית נתונים שגויה עבור הרשת?</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>כתובת onion- שגויה: '%s'</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>אין מספיק מידע על הקובץ</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>תמיד להתחבר למפרקים ברשת &lt;net&gt;‏ (ipv4,‏ ipv6 או onion)</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>בנייה מחדש של מפתח שרשרת המקטעים מקובצי ה־blk000??.dat הנוכחיים.</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>הגדרת גודל מטמון מסדי הנתונים במגה בתים (%d עד %d, בררת מחדל: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>הגדרת קובץ מקטע מרבי בבתים (בררת מחדל: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>ציון קובץ ארנק (בתוך תיקיית הנתונים)</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>תכונה זו מיועדת לכלי בדיקות נסיגה ופיתוח יישומים.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>המקטעים מאומתים…</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>הארנק מאומת…</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>הארנק %s יושב מחוץ לתיקיית הנתונים %s</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>אפשרויות הארנק:</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>עליך לבנות מחדש את מסד הנתונים תוך שימוש ב־‎-reindex על מנת לשנות את ‎-txindex</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>מיובאים מקטעים מקובצי blk000??.dat חיצוניים</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>הרץ פקודה כאשר ההתראה הרלוונטית מתקבלת או כשאנחנו עדים לפיצול ארוך מאוד (%s בשורת הפקודה יוחלף ע"י ההודעה)</translation>
    </message>
    <message>
        <source>Fees (in BTC/Kb) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>העמלות (ב־BTC/ק״ב) הנמוכות מהסכום הזה נחשבות לעמלות אפס ליצירת העברה (בררת מחדל: %s)</translation>
    </message>
    <message>
        <source>Warning: Please check that your computer's date and time are correct! If your clock is wrong Bitcoin Core will not work properly.</source>
        <translation>אזהרה: נא לבדוק שהתאריך והשעה של המחשב שלך נכונים! אם השעון שלך שגוי ליבת ביטקוין לא תעבוד כראוי.</translation>
    </message>
    <message>
        <source>Cannot resolve -whitebind address: '%s'</source>
        <translation>לא ניתן לפתור את הכתובת ‎-whitebind:‏ '%s'</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>התחברות דרך מתווך SOCKS5</translation>
    </message>
    <message>
        <source>Copyright (C) 2009-%i The Bitcoin Core Developers</source>
        <translation>כל הזכויות שמורות (C)‏ 2009‏-%i מתכנתי ליבת ביטקוין</translation>
    </message>
    <message>
        <source>Could not parse -rpcbind value %s as network address</source>
        <translation>לא ניתן לנתח את הערך של ‎-rpcbind שצוין בתור %s ככתובת רשת</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Bitcoin Core</source>
        <translation>אירעה שגיאה בטעינת wallet.dat: הארנק דורש גרסה חדשה יותר של ליבת ביטקוין</translation>
    </message>
    <message>
        <source>Error: Unsupported argument -tor found, use -onion.</source>
        <translation>שגיאה: נמצא ארגומנט בלתי נתמך ‎-tor, יש להשתמש ב־‎-onion.</translation>
    </message>
    <message>
        <source>Fee (in BTC/kB) to add to transactions you send (default: %s)</source>
        <translation>עמלה (ב־BTC/ק״ב) להוספה להעברות שנשלחות ממך (בררת מחדל: %s)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>מידע</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. Bitcoin Core is shutting down.</source>
        <translation>בדיקת התקינות ההתחלתית נכשלה. ליבת ביטקוין תיסגר כעת.</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: '%s'</source>
        <translation>כמות לא תקינה עבור -paytxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: '%s'</source>
        <translation>כמות לא תקינה עבור ‎-mintxfee=&lt;amount&gt;‎:‏ '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s' (must be at least %s)</source>
        <translation>כמות לא תקינה עבור ‎-paytxfee=&lt;amount&gt;‎:‏ '%s' (חייבת להיות לפחות %s)</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: '%s'</source>
        <translation>מסכת הרשת שצוינה עם ‎-whitelist שגויה: '%s'</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: '%s'</source>
        <translation>עליך לציין פתחה עם ‎-whitebind:‏ '%s'</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>אפשרויות ממסר מפרק:</translation>
    </message>
    <message>
        <source>RPC SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>אפשרויות RPC SSL: (נא לעיין בוויקי של ביטקוין לקבלת הנחיות על הגדרת SSL)</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>הגדרות שרת RPC</translation>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation>להשמיט אקראית אחת מתוך כל &lt;n&gt; הודעות רשת</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>שלח מידע דיבאג ועקבה לקונסולה במקום לקובץ debug.log</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>הצגת כל אפשרויות הניפוי (שימוש: ‎--help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>כיווץ הקובץ debug.log בהפעלת הלקוח (בררת מחדל: 1 ללא ‎-debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>החתימה על ההעברה נכשלה</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>זוהי תכנית נסיונית.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>סכום ההעברה קטן מדי</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>סכומי ההעברות חייבים להיות חיוביים</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>סכום ההעברה גדול מדי</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>לא ניתן להתאגד עם הפתחה %s במחשב זה (פעולת האיגוד החזירה את השגיאה %s)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>יש להשתמש ב־UPnP כדי למפות את הפתחה להאזנה (בררת מחדל: 1 בעת האזנה)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>שם משתמש לחיבורי JSON-RPC</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Bitcoin Core to complete</source>
        <translation>יש לכתוב את הארנק מחדש: נא להפעיל את ליבת ביטקוין מחדש כדי להשלים את הפעולה</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>אזהרה</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>אזהרה: הגרסה הזאת מיושנת, יש צורך בשדרוג!</translation>
    </message>
    <message>
        <source>Warning: Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>אזהרה: הארגומנט שאינו נתמך עוד ‎-benchmark לא הופעל, נא להשתמש ב־‎-debug=bench.</translation>
    </message>
    <message>
        <source>Warning: Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>אזהרה: הארגומנט שאינו נתמך עוד ‎-debugnet לא הופעל, נא להשתמש ב־‎-debug=net.</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>עם ההפעלה</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>קובץ wallet.dat מושחת, החילוץ נכשל</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>ססמה לחיבורי JSON-RPC</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>יש לבצע פקודה זו כשהמקטע הטוב ביותר משתנה (%s בפקודה יוחלף בגיבוב המקטע)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>שדרוג הארנק למבנה העדכני</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>יש לסרוק מחדש את שרשרת המקטעים למציאת העברות חסרות בארנק</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>שימוש ב־OpenSSL (https)‎ עבור חיבורי JSON-RPC</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>הודעת העזרה הזו</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>הפעלת בדיקת DNS עבור ‎-addnode,‏ ‎-seednode ו־‎-connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>הכתובות בטעינה…</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>שגיאה בטעינת הקובץ wallet.dat: הארנק מושחת</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>שגיאה בטעינת הקובץ wallet.dat</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>כתובת ‎-proxy לא תקינה: '%s'</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>רשת לא ידועה צוינה דרך ‎-onlynet:‏ '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: '%s'</source>
        <translation>לא ניתן לפתור את הכתובת ‎-bind:‏ '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: '%s'</source>
        <translation>לא ניתן לפתור את הכתובת ‎-externalip:‏ '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s'</source>
        <translation>כמות לא תקינה עבור ‎-paytxfee=&lt;amount&gt;‎:‏ '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>אין מספיק כספים</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>מפתח המקטעים נטען…</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>הוספת מפרק להתחברות ולנסות לשמור על החיבור פתוח</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>הארנק בטעינה…</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>לא ניתן להחזיר את גרסת הארנק</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>לא ניתן לכתוב את כתובת בררת המחדל</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>סריקה מחדש…</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>טעינה הושלמה</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
</context>
</TS>